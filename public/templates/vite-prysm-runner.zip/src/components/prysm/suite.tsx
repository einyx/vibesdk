// The suite row: a mono tag, a machine face for the name, and a quiet
// meta on the right. The primary tag is inverted ink — the landing uses
// it exactly once per grid, for the thing that matters.
export interface SuiteItem {
  tag: string
  name: string
  meta?: string
  /** Invert the tag (ink face, canvas text). Use at most once per list. */
  primary?: boolean
}

export function SuiteList({ items }: { items: SuiteItem[] }) {
  return (
    <div className="grid gap-2.5">
      {items.map((item) => (
        <div key={item.name} className="suite">
          <span className={`suite-tag ${item.primary ? 'suite-tag-primary' : ''}`}>{item.tag}</span>
          <strong className="suite-name">{item.name}</strong>
          {item.meta ? <span className="suite-meta">{item.meta}</span> : null}
        </div>
      ))}
    </div>
  )
}
