// Console chrome: the panel is the one place the product shows a real
// artifact — a terminal, a table, a log — instead of a picture of one.
// The bar carries three dots, a mono uppercase title and, when there is
// one, a quiet flag on the right.
import type { ReactNode } from 'react'

export interface PanelProps {
  /** Mono uppercase title in the bar, e.g. "service inspector". */
  title: string
  /** Quiet mono flag on the right edge, e.g. "illustrative". */
  flag?: string
  /** Hairline-separated foot with a mono label and code line. */
  foot?: { label: string; code: string }
  className?: string
  children: ReactNode
}

export function Panel({ title, flag, foot, className, children }: PanelProps) {
  return (
    <div className={`overflow-hidden rounded-[4px] border border-hairline bg-canvas-soft ${className ?? ''}`}>
      <div className="flex items-center gap-3 border-b border-hairline px-4 py-3">
        <span className="flex gap-[5px]" aria-hidden="true">
          <i className="block h-[7px] w-[7px] rounded-full bg-hairline-strong" />
          <i className="block h-[7px] w-[7px] rounded-full bg-hairline-strong" />
          <i className="block h-[7px] w-[7px] rounded-full bg-hairline-strong" />
        </span>
        <span className="font-mono text-[11px] uppercase tracking-[0.1em] text-body-strong">{title}</span>
        {flag ? (
          <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.1em] text-mute">{flag}</span>
        ) : null}
      </div>
      {children}
      {foot ? (
        <div className="flex items-center gap-3 border-t border-hairline bg-canvas-raised px-[22px] py-3">
          <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-mute">{foot.label}</span>
          <code className="font-mono text-xs text-body-strong">{foot.code}</code>
        </div>
      ) : null}
    </div>
  )
}

// The numbered item: a mono index above a hairline top border. Landing
// sections count things this way — 01, 02, 03 — never with bullets.
export function NumberedItem({ index, title, children }: { index: string; title: string; children: ReactNode }) {
  return (
    <li className="flex flex-col gap-4 border-t border-hairline pt-[22px]">
      <span className="font-mono text-[11px] tracking-[0.1em] text-mute">{index}</span>
      <div>
        <h3 className="mb-2 text-[17px] font-medium tracking-[-0.3px]">{title}</h3>
        <div className="max-w-[40ch] text-sm leading-[1.65] text-body">{children}</div>
      </div>
    </li>
  )
}
