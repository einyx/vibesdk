// Console stats: a mono label above a machine-face number. Numbers are
// tabular so columns of them line up.
export interface Stat {
  label: string
  value: string
  note?: string
}

export function StatRow({ stats }: { stats: Stat[] }) {
  return (
    <dl className="grid grid-cols-2 gap-x-6 gap-y-8 md:grid-cols-4">
      {stats.map((stat) => (
        <div key={stat.label} className="flex flex-col gap-2.5 border-t border-hairline pt-4">
          <dt className="stat-label">{stat.label}</dt>
          <dd className="stat-value">{stat.value}</dd>
          {stat.note ? <span className="stat-note">{stat.note}</span> : null}
        </div>
      ))}
    </dl>
  )
}

// A log line: quiet timestamp, machine message.
export function LogLine({ time, children }: { time: string; children: React.ReactNode }) {
  return (
    <div className="log-line">
      <span className="log-time">{time}</span>
      <span className="log-msg">{children}</span>
    </div>
  )
}
