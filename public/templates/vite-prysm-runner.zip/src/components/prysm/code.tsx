// A mono code block on the raised panel. Token spans are marked with the
// tok-* classes; the key colour is lifted from the mark so it clears
// 4.5:1 on the lighter surface.
import type { ReactNode } from 'react'

export function CodeBlock({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <pre className={`code-block ${className ?? ''}`} aria-label="Code sample">
      <code>{children}</code>
    </pre>
  )
}
