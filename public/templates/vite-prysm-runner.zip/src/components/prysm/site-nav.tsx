// The site nav, shared by every page: the mark and wordmark on the left,
// quiet links in the middle, and an inverted-ink action on the right.
// Links that start with "/" are router links; the rest are anchors.
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { PrysmMark, PrysmWordmark } from '@/components/prysm/mark'

export interface NavItem {
  label: string
  /** "/console" renders a router link; anything else renders an anchor. */
  href: string
}

export interface SiteNavProps {
  /** Lowercase app name for the wordmark; the dot stays terracotta. */
  brand: string
  items: NavItem[]
  ctaLabel?: string
  ctaTo?: string
  /** Quiet action on the far left of the CTA, e.g. "Sign in". */
  signInHref?: string
}

export function SiteNav({ brand, items, ctaLabel = 'Open console', ctaTo = '/console', signInHref }: SiteNavProps) {
  return (
    <nav aria-label="Main navigation" className="sticky top-0 z-10 border-b border-hairline bg-canvas">
      <div className="mx-auto flex h-[60px] max-w-[1200px] items-center gap-8 px-6">
        <Link to="/" aria-label={`${brand} home`} className="inline-flex flex-shrink-0 items-center gap-[9px]">
          <PrysmMark className="h-[19px] w-[19px] text-mark" />
          <PrysmWordmark name={brand} />
        </Link>
        <div className="hidden gap-[26px] text-sm font-medium text-body md:flex">
          {items.map((item) =>
            item.href.startsWith('/') ? (
              <Link key={item.href} to={item.href} className="py-1.5 transition-colors hover:text-ink">
                {item.label}
              </Link>
            ) : (
              <a key={item.href} href={item.href} className="py-1.5 transition-colors hover:text-ink">
                {item.label}
              </a>
            )
          )}
        </div>
        <div className="ml-auto flex items-center gap-2.5">
          {signInHref ? (
            <a href={signInHref} className="rounded-[3px] px-3 py-2 text-sm font-medium text-body transition-colors hover:text-ink">
              Sign in
            </a>
          ) : null}
          <Button asChild className="rounded-[3px] px-3.5 py-2 text-sm font-medium">
            <Link to={ctaTo}>
              {ctaLabel} <span aria-hidden="true">&nbsp;↗</span>
            </Link>
          </Button>
        </div>
      </div>
    </nav>
  )
}
