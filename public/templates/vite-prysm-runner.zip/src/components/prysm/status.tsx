// Status, the way the system reads it: a small dot and a word. The
// terracotta appears only when something needs attention; healthy is
// neutral. Chromatic discipline, per the design rules.
export type ServiceStatus = 'healthy' | 'degraded'

export function StatusCell({ status }: { status: ServiceStatus }) {
  const healthy = status === 'healthy'
  return (
    <span className="flex items-center gap-2">
      <span aria-hidden="true" className={`h-1.5 w-1.5 rounded-full ${healthy ? 'bg-body' : 'bg-mark'}`} />
      <span className={healthy ? 'text-body' : 'text-ink'}>{status}</span>
    </span>
  )
}
