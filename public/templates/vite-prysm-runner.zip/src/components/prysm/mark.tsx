// The Prysm mark: an upward stroke crossed by two diagonals, drawn on a
// 32x32 grid with a 1.8 stroke and round joins. This is the same path the
// prysm.sh landing inlines; keep the two in step and do not redraw it.
//
// The stroke is `currentColor`, so set the colour on the element — the
// terracotta (`text-mark`) on the dark canvas, `text-mark-on-light` when
// the mark sits on a light surface.

export function PrysmMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinejoin="round"
      className={className}
    >
      <path d="M4 26 16 5l12 21H4Zm12-21v21M4 26l18-10" />
    </svg>
  )
}

// The wordmark: lowercase name, then the terracotta dot on the baseline.
// Set the app's own name as the text; the dot stays the mark's colour.
export function PrysmWordmark({ name, className }: { name: string; className?: string }) {
  return (
    <span className={`inline-flex items-baseline text-[19px] font-medium leading-none tracking-[-0.5px] ${className ?? ''}`}>
      <span>{name}</span>
      <span className="text-mark" aria-hidden="true">
        .
      </span>
    </span>
  )
}
