// The explorer: a file tree beside the file it selects. It is the one
// place an app shows the artifact a developer writes, rather than a
// picture of one. The tree draws its own caret and sheet, so it needs no
// image.
import type { ReactNode } from 'react'

export interface ExplorerEntry {
  name: string
  kind: 'dir' | 'file'
  /** Nesting level: 0 sits at the root, 1 under a directory, and so on. */
  depth?: number
}

export interface ExplorerProps {
  /** Path shown in the code pane's bar, e.g. "app.yaml". */
  path: string
  /** Language tag on the right of the bar, e.g. "yaml". */
  lang?: string
  /** Flat, ordered tree entries; `depth` indents. */
  entries: ExplorerEntry[]
  /** The currently selected file by name. */
  active: string
  /** Called when a file row is chosen. Omit for a read-only tree. */
  onSelect?: (name: string) => void
  /** Hairline foot with a mono label and code line. */
  foot?: { label: string; code: string }
  className?: string
  children: ReactNode
}

export function Explorer({ path, lang, entries, active, onSelect, foot, className, children }: ExplorerProps) {
  return (
    <div className={`grid grid-cols-1 overflow-hidden rounded-[4px] border border-hairline bg-canvas-soft md:grid-cols-[250px_minmax(0,1fr)] ${className ?? ''}`}>
      <div role="presentation" className="border-b border-hairline bg-canvas-raised py-3.5 md:border-b-0 md:border-r">
        {entries.map((entry) => {
          const selectable = entry.kind === 'file' && onSelect !== undefined
          const classes = [
            'tree-row',
            entry.kind === 'dir' ? 'dir' : '',
            entry.kind === 'file' && entry.name === active ? 'active' : '',
          ]
            .filter(Boolean)
            .join(' ')
          const style = entry.depth ? { paddingLeft: `${18 + entry.depth * 19}px` } : undefined

          if (selectable) {
            return (
              <button
                key={entry.name}
                type="button"
                className={classes}
                style={style}
                onClick={() => onSelect(entry.name)}
                aria-current={entry.name === active ? 'true' : undefined}
              >
                {entry.kind === 'dir' ? <span className="tree-caret" aria-hidden="true" /> : <span className="tree-icon" aria-hidden="true" />}
                {entry.name}
              </button>
            )
          }
          return (
            <div key={entry.name} className={classes} style={style}>
              {entry.kind === 'dir' ? <span className="tree-caret" aria-hidden="true" /> : <span className="tree-icon" aria-hidden="true" />}
              {entry.name}
            </div>
          )
        })}
      </div>

      <div className="min-w-0">
        <div className="explorer-bar">
          <span className="explorer-path">{path}</span>
          {lang ? <span className="explorer-lang">{lang}</span> : null}
        </div>
        {children}
        {foot ? (
          <div className="flex items-center gap-3 border-t border-hairline bg-canvas-raised px-[24px] py-3">
            <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-mute">{foot.label}</span>
            <code className="font-mono text-xs text-body-strong">{foot.code}</code>
          </div>
        ) : null}
      </div>
    </div>
  )
}
