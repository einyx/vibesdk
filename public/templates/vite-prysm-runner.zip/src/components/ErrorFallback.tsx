import React from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

// The error screen, in the Prysm system: no gradient washes, no orange
// pulse. A raised card on the canvas, hairline borders, mono status line.
export interface ErrorFallbackProps {
  title?: string;
  message?: string;
  error?: Error | any;
  onRetry?: () => void;
  onGoHome?: () => void;
  showErrorDetails?: boolean;
  statusMessage?: string;
}

export function ErrorFallback({
  title = "Something went wrong",
  message = "The application hit an error it could not recover from. The rest of the page has been stopped.",
  error,
  onRetry,
  onGoHome,
  showErrorDetails = true,
  statusMessage = "The details below are what the app recorded"
}: ErrorFallbackProps) {
  const handleRetry = () => {
    if (onRetry) {
      onRetry();
    } else {
      window.location.reload();
    }
  };

  const handleGoHome = () => {
    if (onGoHome) {
      onGoHome();
    } else {
      window.location.href = '/';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <Card className="relative shadow-soft">
          <CardContent className="p-8 space-y-6">
            {/* Icon and title */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-hairline bg-canvas-soft">
                  <AlertTriangle className="h-5 w-5 text-mark" />
                </div>
                <h1 className="text-xl font-medium tracking-tight">{title}</h1>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">{message}</p>
            </div>

            {/* Status indicator: a machine would read this line. */}
            {statusMessage && (
              <div className="flex items-center gap-2.5 font-mono text-xs uppercase tracking-[0.1em] text-mute">
                <span className="status-dot" aria-hidden="true" />
                <span>{statusMessage}</span>
              </div>
            )}

            {/* Action buttons */}
            <div className="space-y-3">
              <Button onClick={handleRetry} className="w-full">
                <RefreshCw className="mr-2 h-4 w-4" />
                Try again
              </Button>
              <Button onClick={handleGoHome} variant="secondary" className="w-full">
                <Home className="mr-2 h-4 w-4" />
                Go to homepage
              </Button>
            </div>

            {/* Error details (collapsible) */}
            {process.env.NODE_ENV === 'development' && showErrorDetails && error && (
              <details className="mt-2 rounded border border-hairline bg-canvas-soft p-4">
                <summary className="cursor-pointer font-mono text-xs uppercase tracking-[0.1em] text-mute transition-colors hover:text-foreground">
                  Error details (development only)
                </summary>
                <pre className="mt-3 max-h-40 overflow-auto font-mono text-xs text-muted-foreground">
                  {error.message || error.toString()}
                  {error.stack && '\n\n' + error.stack + '\n\n' + error.componentStack}
                </pre>
              </details>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
