// The console page: the "consoles" half of the design system. Same nav,
// same tokens — hairline sections, DM Mono for anything a machine would
// read, the terracotta only where something needs attention.
//
// Everything is a mock with the flag that says so. Replace the numbers,
// the table and the log with the application's own data from the worker.

import { useState } from 'react'
import { Panel } from '@/components/prysm/panel'
import { CodeBlock } from '@/components/prysm/code'
import { Explorer, type ExplorerEntry } from '@/components/prysm/explorer'
import { LogLine, StatRow } from '@/components/prysm/stat'
import { SiteNav } from '@/components/prysm/site-nav'
import { StatusCell } from '@/components/prysm/status'

const APP_NAME = 'appname'

// Illustrative. Point these at the worker — /api/test answers today.
const STATS = [
  { label: 'requests · 24h', value: '1.2M', note: '↑ 4% vs yesterday' },
  { label: 'p50', value: '31ms', note: 'edge, global' },
  { label: 'p99', value: '92ms', note: 'cache misses included' },
  { label: 'errors', value: '0.02%', note: '5xx only' },
]

const SERVICES = [
  { name: 'web', status: 'healthy' as const, p50: '12ms', p99: '48ms', region: 'global' },
  { name: 'api', status: 'healthy' as const, p50: '31ms', p99: '92ms', region: 'global' },
  { name: 'worker', status: 'degraded' as const, p50: '—', p99: '—', region: 'eu' },
  { name: 'cron', status: 'healthy' as const, p50: '210ms', p99: '480ms', region: 'eu' },
]

const EVENTS = [
  { time: '14:02:11', msg: 'deploy web@9f2c — rollout complete, 100%' },
  { time: '13:47:58', msg: 'worker latency over budget — degraded (p99 > 2s)' },
  { time: '13:12:04', msg: 'cron tick — queue drained in 480ms' },
  { time: '11:30:41', msg: 'certificate renewed — *.appname.example' },
]

const CONFIG_FILES: Record<string, ExplorerEntry[]> = {
  'app.yaml': [
    { name: 'app.yaml', kind: 'file', depth: 0 },
    { name: 'runtime', kind: 'dir', depth: 0 },
    { name: 'limits.yaml', kind: 'file', depth: 1 },
  ],
  'limits.yaml': [
    { name: 'app.yaml', kind: 'file', depth: 0 },
    { name: 'runtime', kind: 'dir', depth: 0 },
    { name: 'limits.yaml', kind: 'file', depth: 1 },
  ],
}

export function ConsolePage() {
  const [active, setActive] = useState('app.yaml')

  return (
    <div className="min-h-screen bg-canvas text-ink">
      <SiteNav
        brand={APP_NAME}
        items={[
          { label: 'Metrics', href: '#metrics' },
          { label: 'Events', href: '#events' },
          { label: 'Config', href: '#config' },
        ]}
        ctaLabel="View site"
        ctaTo="/"
      />

      <main>
        {/* ---------- Page head ---------- */}
        <header className="mx-auto max-w-[1200px] px-6 pb-14 pt-16">
          <p className="eyebrow mb-[22px]">
            <span className="status-dot" aria-hidden="true" /> console — illustrative data
          </p>
          <h1 className="display-2 mb-5">Everything, on one page.</h1>
          <p className="max-w-[46ch] text-base leading-[1.6] text-body">
            The shape every console page takes: a head with an eyebrow, a stat row, hairline tables, and one panel per
            artifact.
          </p>
        </header>

        {/* ---------- Stats ---------- */}
        <section aria-label="Key numbers" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-12">
          <StatRow stats={STATS} />
        </section>

        {/* ---------- Metrics ---------- */}
        <section id="metrics" aria-labelledby="metrics-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-12">
          <h2 id="metrics-title" className="eyebrow mb-6">
            services
          </h2>
          <div className="overflow-hidden rounded-[4px] border border-hairline bg-canvas-soft">
            <table className="console-table">
              <thead>
                <tr>
                  <th scope="col">service</th>
                  <th scope="col">status</th>
                  <th scope="col">region</th>
                  <th scope="col">p50</th>
                  <th scope="col">p99</th>
                </tr>
              </thead>
              <tbody>
                {SERVICES.map((row) => (
                  <tr key={row.name}>
                    <td className="text-ink">{row.name}</td>
                    <td>
                      <StatusCell status={row.status} />
                    </td>
                    <td>{row.region}</td>
                    <td className="tabular-nums">{row.p50}</td>
                    <td className="tabular-nums">{row.p99}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ---------- Events ---------- */}
        <section id="events" aria-labelledby="events-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-12">
          <h2 id="events-title" className="eyebrow mb-6">
            events
          </h2>
          <Panel title="event log" flag="last 24h" foot={{ label: 'retention', code: '7 days' }} className="max-w-[880px]">
            <div className="py-2">
              {EVENTS.map((event) => (
                <LogLine key={event.time} time={event.time}>
                  {event.msg}
                </LogLine>
              ))}
            </div>
          </Panel>
        </section>

        {/* ---------- Config ---------- */}
        <section id="config" aria-labelledby="config-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-12">
          <h2 id="config-title" className="eyebrow mb-6">
            config
          </h2>
          <Explorer
            path={active}
            lang="yaml"
            entries={CONFIG_FILES[active]}
            active={active}
            onSelect={setActive}
            foot={{ label: 'source of truth', code: 'versioned with the code it runs' }}
            className="max-w-[880px]"
          >
            {active === 'app.yaml' ? (
              <CodeBlock>
                <span className="tok-key">name</span>: <span className="tok-str">web-server</span>
                {'\n'}
                <span className="tok-key">tenant</span>: <span className="tok-str">acme</span>
                {'\n\n'}
                <span className="tok-key">identity</span>:
                {'\n'}
                {'  '}<span className="tok-key">audience</span>: <span className="tok-str">web-api</span>
                {'\n'}
                {'  '}<span className="tok-key">scopes</span>: [<span className="tok-str">read</span>, <span className="tok-str">write</span>]
              </CodeBlock>
            ) : (
              <CodeBlock>
                <span className="tok-key">deadline</span>: <span className="tok-num">30s</span>
                {'\n'}
                <span className="tok-key">pids</span>: <span className="tok-num">256</span>
                {'\n'}
                <span className="tok-key">disk</span>: <span className="tok-num">1Gi</span>
              </CodeBlock>
            )}
          </Explorer>
        </section>
      </main>
    </div>
  )
}
