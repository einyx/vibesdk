// The home page, in the Prysm design system: a warm dark canvas, one
// off-white, hairline borders, and a single terracotta accent the brand
// mark carries. Inter for narrative, DM Mono for anything a machine would
// read.
//
// Everything here is a working mock — replace the copy, the wordmark and
// the table with the application's own; keep the system. The design rules
// live in `prompts/usage.md`.

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { PrysmMark, PrysmWordmark } from '@/components/prysm/mark'
import { NumberedItem, Panel } from '@/components/prysm/panel'

// The wordmark text. Replace with the application's name; it stays
// lowercase and the dot stays terracotta.
const APP_NAME = 'appname'

type ServiceStatus = 'healthy' | 'degraded'

interface ServiceRow {
  name: string
  status: ServiceStatus
  p50: string
  p99: string
}

// Illustrative data. Point this at the worker (`/api/test` answers today;
// see worker/userRoutes.ts) and render real numbers in its place.
const SERVICES: Record<'production' | 'staging', ServiceRow[]> = {
  production: [
    { name: 'web', status: 'healthy', p50: '12ms', p99: '48ms' },
    { name: 'api', status: 'healthy', p50: '31ms', p99: '92ms' },
    { name: 'worker', status: 'degraded', p50: '—', p99: '—' },
  ],
  staging: [
    { name: 'web', status: 'healthy', p50: '14ms', p99: '51ms' },
    { name: 'api', status: 'healthy', p50: '29ms', p99: '88ms' },
    { name: 'worker', status: 'healthy', p50: '45ms', p99: '120ms' },
  ],
}

const FOUNDATIONS = ['TypeScript', 'React', 'Tailwind', 'Hono', 'Cloudflare Workers']

function StatusCell({ status }: { status: ServiceStatus }) {
  // Chromatic discipline: the terracotta appears only when something
  // needs attention. Healthy is neutral.
  const healthy = status === 'healthy'
  return (
    <span className="flex items-center gap-2">
      <span aria-hidden="true" className={`h-1.5 w-1.5 rounded-full ${healthy ? 'bg-body' : 'bg-mark'}`} />
      <span className={healthy ? 'text-body' : 'text-ink'}>{status}</span>
    </span>
  )
}

function ServiceInspector() {
  const [environment, setEnvironment] = useState<'production' | 'staging'>('production')
  const rows = SERVICES[environment]

  return (
    <Panel title="service inspector" flag="illustrative" foot={{ label: 'source', code: '/api/metrics' }}>
      <div className="flex gap-1.5 px-4 pt-4" role="group" aria-label="Environment">
        {(Object.keys(SERVICES) as Array<keyof typeof SERVICES>).map((env) => (
          <button
            key={env}
            type="button"
            aria-pressed={environment === env}
            onClick={() => setEnvironment(env)}
            className="min-h-[36px] cursor-pointer rounded-[3px] border border-transparent px-3 py-[7px] text-[13px] text-mute transition-colors hover:text-body-strong aria-pressed:border-hairline-strong aria-pressed:bg-canvas-raised aria-pressed:text-ink"
          >
            {env}
          </button>
        ))}
      </div>
      <table className="console-table mt-4" aria-live="polite">
        <thead>
          <tr>
            <th scope="col">service</th>
            <th scope="col">status</th>
            <th scope="col">p50</th>
            <th scope="col">p99</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.name}>
              <td className="text-ink">{row.name}</td>
              <td>
                <StatusCell status={row.status} />
              </td>
              <td className="tabular-nums">{row.p50}</td>
              <td className="tabular-nums">{row.p99}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="min-h-[56px] px-[22px] pb-[18px] pt-3 text-[13px] leading-[1.55] text-body">
        Sampled every 30 seconds. The worker answers today at <code className="font-mono text-body-strong">/api/test</code>;
        point the table at real numbers when there are any.
      </p>
    </Panel>
  )
}

export function HomePage() {
  return (
    <div className="min-h-screen bg-canvas text-ink">
      {/* ---------- Nav ---------- */}
      <nav aria-label="Main navigation" className="sticky top-0 z-10 border-b border-hairline bg-canvas">
        <div className="mx-auto flex h-[60px] max-w-[1200px] items-center gap-8 px-6">
          <a href="#" aria-label={`${APP_NAME} home`} className="inline-flex items-center gap-[9px]">
            <PrysmMark className="h-[19px] w-[19px] text-mark" />
            <PrysmWordmark name={APP_NAME} />
          </a>
          <div className="flex gap-[26px] text-sm font-medium text-body">
            <a href="#inspector" className="py-1.5 transition-colors hover:text-ink">
              Inspector
            </a>
            <a href="#foundations" className="py-1.5 transition-colors hover:text-ink">
              Foundations
            </a>
            <a href="#starter" className="py-1.5 transition-colors hover:text-ink">
              The starter
            </a>
          </div>
          <div className="ml-auto flex items-center gap-2.5">
            <a href="#" className="rounded-[3px] px-3 py-2 text-sm font-medium text-body transition-colors hover:text-ink">
              Sign in
            </a>
            <Button asChild className="rounded-[3px] px-3.5 py-2 text-sm font-medium">
              <a href="#inspector">
                Open console <span aria-hidden="true">&nbsp;↗</span>
              </a>
            </Button>
          </div>
        </div>
      </nav>

      <main>
        {/* ---------- Hero ---------- */}
        <section
          aria-labelledby="hero-title"
          className="mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-[72px] px-6 pb-20 pt-24 lg:grid-cols-2"
        >
          <div className="max-w-[560px]">
            <p className="eyebrow mb-[22px]">
              <span className="status-dot" aria-hidden="true" /> all systems nominal
            </p>
            <h1 id="hero-title" className="display-1 mb-6">
              The console your
              <br />
              service deserved.
            </h1>
            <p className="mb-[30px] max-w-[46ch] text-lg leading-[1.55] text-body">
              A working starter in the Prysm design system: a warm dark canvas, hairline borders, one accent carried
              by the mark. Describe your application and this page becomes its front door.
            </p>
            <div className="flex flex-wrap items-center gap-6">
              <Button asChild className="rounded-[3px] px-[18px] py-2.5 text-sm font-medium">
                <a href="#inspector">
                  Open console <span aria-hidden="true">&nbsp;↗</span>
                </a>
              </Button>
              <a href="#starter" className="text-link">
                Read the design notes <span aria-hidden="true">→</span>
              </a>
            </div>
            <p className="mb-0 mt-7 font-mono text-[11px] tracking-[0.04em] text-mute">
              react <span className="px-2 text-[#a39b92]">/</span> typescript{' '}
              <span className="px-2 text-[#a39b92]">/</span> cloudflare workers
            </p>
          </div>
          <div id="inspector">
            <ServiceInspector />
          </div>
        </section>

        {/* ---------- Foundations strip ---------- */}
        <section
          id="foundations"
          aria-label="Foundations"
          className="mx-auto flex max-w-[1200px] flex-wrap items-center gap-10 border-y border-hairline px-6 py-[30px]"
        >
          <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-mute">built on</span>
          {FOUNDATIONS.map((name) => (
            <strong key={name} className="text-[15px] font-medium tracking-[-0.2px] text-body-strong">
              {name}
            </strong>
          ))}
        </section>

        {/* ---------- The starter, counted ---------- */}
        <section id="starter" aria-labelledby="starter-title" className="mx-auto max-w-[1200px] px-6 py-[88px]">
          <div className="mb-14 grid grid-cols-1 items-end gap-[80px] lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <p className="eyebrow mb-5">the starter</p>
              <h2 id="starter-title" className="display-2">
                Less scaffolding.
                <br />
                More shipping.
              </h2>
            </div>
            <p className="max-w-[46ch] text-base leading-[1.6] text-body">
              Everything on this page is the system: tokens in <code className="font-mono text-body-strong">index.css</code>,
              the palette in <code className="font-mono text-body-strong">tailwind.config.js</code>, chrome in{' '}
              <code className="font-mono text-body-strong">src/components/prysm/</code>. Nothing else ships.
            </p>
          </div>
          <ol className="grid grid-cols-1 list-none gap-10 p-0 md:grid-cols-3">
            <NumberedItem index="01" title="The system, already mixed.">
              Canvas, ink, hairline and mark are tokens, not hex codes. Build inside the scale and the app reads as
              Prysm without a style guide open.
            </NumberedItem>
            <NumberedItem index="02" title="Console chrome in the box.">
              The panel draws its own bar, dots and flag. Tables set in DM Mono, numbers tabular, hairline rows — the
              way a console reads.
            </NumberedItem>
            <NumberedItem index="03" title="A worker underneath.">
              Hono routes live in <code className="font-mono text-body-strong">worker/userRoutes.ts</code>. The
              inspector's table answers from the worker today; aim it at real metrics tomorrow.
            </NumberedItem>
          </ol>
        </section>
      </main>

      {/* ---------- Footer ---------- */}
      <footer className="border-t border-hairline">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center gap-x-10 gap-y-4 px-6 py-8">
          <a href="#" aria-label={`${APP_NAME} home`} className="inline-flex items-center gap-[9px]">
            <PrysmMark className="h-[19px] w-[19px] text-mark" />
            <PrysmWordmark name={APP_NAME} />
          </a>
          <p className="text-sm text-body">Built in the Prysm design system.</p>
          <nav aria-label="Footer navigation" className="ml-auto flex gap-[26px] text-sm font-medium text-body">
            <a href="#starter" className="transition-colors hover:text-ink">
              The starter
            </a>
            <a href="#foundations" className="transition-colors hover:text-ink">
              Foundations
            </a>
            <a href="https://prysm.sh" className="transition-colors hover:text-ink">
              prysm.sh <span aria-hidden="true">↗</span>
            </a>
          </nav>
        </div>
      </footer>
    </div>
  )
}
