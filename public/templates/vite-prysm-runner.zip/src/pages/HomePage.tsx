// The home page, in the Prysm design system: a warm dark canvas, one
// off-white, hairline borders, and a single terracotta accent the brand
// mark carries. Inter for narrative, DM Mono for anything a machine would
// read.
//
// Everything here is a working mock — replace the copy, the wordmark and
// the table with the application's own; keep the system. The design rules
// live in `prompts/usage.md`.

import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { SiteNav } from '@/components/prysm/site-nav'
import { PrysmMark, PrysmWordmark } from '@/components/prysm/mark'
import { NumberedItem, Panel } from '@/components/prysm/panel'
import { CodeBlock } from '@/components/prysm/code'
import { Explorer, type ExplorerEntry } from '@/components/prysm/explorer'
import { SuiteList } from '@/components/prysm/suite'
import { StatusCell, type ServiceStatus } from '@/components/prysm/status'

// The wordmark text. Replace with the application's name; it stays
// lowercase and the dot stays terracotta.
const APP_NAME = 'appname'

interface ServiceRow {
  name: string
  status: ServiceStatus
  p50: string
  p99: string
}

// Illustrative data. Point this at the worker (`/api/test` answers today;
// see worker/userRoutes.ts) and render real numbers in its place.
const SERVICES: Record<'production' | 'staging', ServiceRow[]> = {
  production: [
    { name: 'web', status: 'healthy', p50: '12ms', p99: '48ms' },
    { name: 'api', status: 'healthy', p50: '31ms', p99: '92ms' },
    { name: 'worker', status: 'degraded', p50: '—', p99: '—' },
  ],
  staging: [
    { name: 'web', status: 'healthy', p50: '14ms', p99: '51ms' },
    { name: 'api', status: 'healthy', p50: '29ms', p99: '88ms' },
    { name: 'worker', status: 'healthy', p50: '45ms', p99: '120ms' },
  ],
}

const FOUNDATIONS = ['TypeScript', 'React', 'Tailwind', 'Hono', 'Cloudflare Workers']

const CONFIG_FILES: Record<string, ExplorerEntry[]> = {
  'app.yaml': [
    { name: 'app.yaml', kind: 'file', depth: 0 },
    { name: 'Dockerfile', kind: 'file', depth: 0 },
    { name: 'runtime', kind: 'dir', depth: 0 },
    { name: 'limits.yaml', kind: 'file', depth: 1 },
    { name: 'network.yaml', kind: 'file', depth: 1 },
    { name: 'policies', kind: 'dir', depth: 0 },
    { name: 'default-deny.yaml', kind: 'file', depth: 1 },
  ],
  'limits.yaml': [
    { name: 'app.yaml', kind: 'file', depth: 0 },
    { name: 'runtime', kind: 'dir', depth: 0 },
    { name: 'limits.yaml', kind: 'file', depth: 1 },
  ],
}

const SUITES = [
  { tag: 'frontend', name: 'React 19', meta: 'react-router 6', primary: true },
  { tag: 'styles', name: 'tailwind', meta: 'shadcn ui' },
  { tag: 'api', name: 'hono', meta: 'worker/userRoutes.ts' },
  { tag: 'platform', name: 'workers', meta: 'previews included' },
]

function ServiceInspector() {
  const [environment, setEnvironment] = useState<'production' | 'staging'>('production')
  const rows = SERVICES[environment]

  return (
    <Panel title="service inspector" flag="illustrative" foot={{ label: 'source', code: '/api/metrics' }}>
      <div className="flex gap-1.5 px-4 pt-4" role="group" aria-label="Environment">
        {(Object.keys(SERVICES) as Array<keyof typeof SERVICES>).map((env) => (
          <button
            key={env}
            type="button"
            aria-pressed={environment === env}
            onClick={() => setEnvironment(env)}
            className="min-h-[36px] cursor-pointer rounded-[3px] border border-transparent px-3 py-[7px] text-[13px] text-mute transition-colors hover:text-body-strong aria-pressed:border-hairline-strong aria-pressed:bg-canvas-raised aria-pressed:text-ink"
          >
            {env}
          </button>
        ))}
      </div>
      <table className="console-table mt-4" aria-live="polite">
        <thead>
          <tr>
            <th scope="col">service</th>
            <th scope="col">status</th>
            <th scope="col">p50</th>
            <th scope="col">p99</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.name}>
              <td className="text-ink">{row.name}</td>
              <td>
                <StatusCell status={row.status} />
              </td>
              <td className="tabular-nums">{row.p50}</td>
              <td className="tabular-nums">{row.p99}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="min-h-[56px] px-[22px] pb-[18px] pt-3 text-[13px] leading-[1.55] text-body">
        Sampled every 30 seconds. The worker answers today at <code className="font-mono text-body-strong">/api/test</code>;
        point the table at real numbers when there are any.
      </p>
    </Panel>
  )
}

function ConfigExplorer() {
  const [active, setActive] = useState('app.yaml')

  return (
    <Explorer
      path={active}
      lang="yaml"
      entries={CONFIG_FILES[active]}
      active={active}
      onSelect={setActive}
      foot={{ label: 'source of truth', code: 'the file is versioned with the code it runs' }}
    >
      {active === 'app.yaml' ? (
        <CodeBlock>
          <span className="tok-c"># the application</span>
          {'\n'}
          <span className="tok-key">name</span>: <span className="tok-str">web-server</span>
          {'\n'}
          <span className="tok-key">image</span>: <span className="tok-str">registry.example/web-server@sha256:9f2c</span>
          {'\n\n'}
          <span className="tok-c"># the limits</span>
          {'\n'}
          <span className="tok-key">runtime</span>:
          {'\n'}
          {'  '}<span className="tok-key">cpus</span>: <span className="tok-num">&quot;2&quot;</span>
          {'\n'}
          {'  '}<span className="tok-key">memory</span>: <span className="tok-num">512Mi</span>
          {'\n\n'}
          <span className="tok-c"># the identity</span>
          {'\n'}
          <span className="tok-key">identity</span>:
          {'\n'}
          {'  '}<span className="tok-key">audience</span>: <span className="tok-str">web-api</span>
          {'\n'}
          {'  '}<span className="tok-key">scopes</span>: [<span className="tok-str">read</span>, <span className="tok-str">write</span>]
          {'\n\n'}
          <span className="tok-c"># the secrets</span>
          {'\n'}
          <span className="tok-key">secrets</span>:
          {'\n'}
          {'  '}- <span className="tok-str">DATABASE_URL</span>
        </CodeBlock>
      ) : (
        <CodeBlock>
          <span className="tok-c"># what the plan allows, not what was asked</span>
          {'\n'}
          <span className="tok-key">deadline</span>: <span className="tok-num">30s</span>
          {'\n'}
          <span className="tok-key">pids</span>: <span className="tok-num">256</span>
          {'\n'}
          <span className="tok-key">disk</span>: <span className="tok-num">1Gi</span>
        </CodeBlock>
      )}
    </Explorer>
  )
}

export function HomePage() {
  return (
    <div className="min-h-screen bg-canvas text-ink">
      <SiteNav
        brand={APP_NAME}
        items={[
          { label: 'Inspector', href: '#inspector' },
          { label: 'Config', href: '#config' },
          { label: 'Questions', href: '#questions' },
        ]}
      />

      <main>
        {/* ---------- Hero ---------- */}
        <section
          aria-labelledby="hero-title"
          className="mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-[72px] px-6 pb-20 pt-24 lg:grid-cols-2"
        >
          <div className="max-w-[560px]">
            <p className="eyebrow mb-[22px]">
              <span className="status-dot" aria-hidden="true" /> all systems nominal
            </p>
            <h1 id="hero-title" className="display-1 mb-6">
              The console your
              <br />
              service deserved.
            </h1>
            <p className="mb-[30px] max-w-[46ch] text-lg leading-[1.55] text-body">
              A working starter in the Prysm design system: a warm dark canvas, hairline borders, one accent carried
              by the mark. Describe your application and this page becomes its front door.
            </p>
            <div className="flex flex-wrap items-center gap-6">
              <Button asChild className="rounded-[3px] px-[18px] py-2.5 text-sm font-medium">
                <Link to="/console">
                  Open console <span aria-hidden="true">&nbsp;↗</span>
                </Link>
              </Button>
              <a href="#config" className="text-link">
                Read the design notes <span aria-hidden="true">→</span>
              </a>
            </div>
            <p className="mb-0 mt-7 font-mono text-[11px] tracking-[0.04em] text-mute">
              react <span className="px-2 text-[#a39b92]">/</span> typescript{' '}
              <span className="px-2 text-[#a39b92]">/</span> cloudflare workers
            </p>
          </div>
          <div id="inspector">
            <ServiceInspector />
          </div>
        </section>

        {/* ---------- Foundations strip ---------- */}
        <section
          id="foundations"
          aria-label="Foundations"
          className="mx-auto flex max-w-[1200px] flex-wrap items-center gap-10 border-y border-hairline px-6 py-[30px]"
        >
          <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-mute">built on</span>
          {FOUNDATIONS.map((name) => (
            <strong key={name} className="text-[15px] font-medium tracking-[-0.2px] text-body-strong">
              {name}
            </strong>
          ))}
        </section>

        {/* ---------- The starter, counted ---------- */}
        <section id="starter" aria-labelledby="starter-title" className="mx-auto max-w-[1200px] px-6 py-[88px]">
          <div className="mb-14 grid grid-cols-1 items-end gap-[80px] lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <p className="eyebrow mb-5">the starter</p>
              <h2 id="starter-title" className="display-2">
                Less scaffolding.
                <br />
                More shipping.
              </h2>
            </div>
            <p className="max-w-[46ch] text-base leading-[1.6] text-body">
              Everything on this page is the system: tokens in <code className="font-mono text-body-strong">index.css</code>,
              the palette in <code className="font-mono text-body-strong">tailwind.config.js</code>, chrome in{' '}
              <code className="font-mono text-body-strong">src/components/prysm/</code>. Nothing else ships.
            </p>
          </div>
          <ol className="grid grid-cols-1 list-none gap-10 p-0 md:grid-cols-3">
            <NumberedItem index="01" title="The system, already mixed.">
              Canvas, ink, hairline and mark are tokens, not hex codes. Build inside the scale and the app reads as
              Prysm without a style guide open.
            </NumberedItem>
            <NumberedItem index="02" title="Console chrome in the box.">
              The panel draws its own bar, dots and flag. Tables set in DM Mono, numbers tabular, hairline rows — the
              way a console reads.
            </NumberedItem>
            <NumberedItem index="03" title="A worker underneath.">
              Hono routes live in <code className="font-mono text-body-strong">worker/userRoutes.ts</code>. The
              inspector's table answers from the worker today; aim it at real metrics tomorrow.
            </NumberedItem>
          </ol>
        </section>

        {/* ---------- Config explorer ---------- */}
        <section id="config" aria-labelledby="config-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-[88px]">
          <div className="max-w-[620px]">
            <h2 id="config-title" className="display-2 mb-5">
              Your application,
              <br />
              defined in code.
            </h2>
            <p className="max-w-[46ch] text-base leading-[1.6] text-body">
              The explorer is the one place an app shows the artifact a developer writes, rather than a picture of
              one. Pick a file; the pane follows.
            </p>
          </div>
          <div className="mt-12">
            <ConfigExplorer />
          </div>
        </section>

        {/* ---------- The stack, as suites ---------- */}
        <section aria-labelledby="stack-title" className="mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-[80px] border-t border-hairline px-6 py-[88px] lg:grid-cols-2">
          <div>
            <p className="eyebrow mb-[22px]">the stack</p>
            <h2 id="stack-title" className="display-2 mb-5">
              Familiar parts,
              <br />
              assembled once.
            </h2>
            <p className="max-w-[46ch] text-base leading-[1.6] text-body">
              Nothing exotic underneath: the pieces most teams already speak, wired to a worker that answers on{' '}
              <code className="font-mono text-body-strong">/api</code>. Swap any of them; the tokens outlive the parts.
            </p>
            <p className="fine-print">* Previews deploy per branch. The list above is what the template ships, not a ceiling.</p>
          </div>
          <div className="rounded-[4px] border border-hairline bg-canvas-soft p-6">
            <SuiteList items={SUITES} />
            <p className="mt-[18px] text-xs leading-[1.6] text-mute">
              The worker answers today at <code className="font-mono text-body-strong">/api/test</code>; previews ride the same design tokens.
            </p>
          </div>
        </section>

        {/* ---------- Questions ---------- */}
        <section id="questions" aria-labelledby="questions-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-[88px]">
          <div className="mb-14 grid grid-cols-1 items-end gap-[80px] lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <p className="eyebrow mb-5">no fine-print surprises</p>
              <h2 id="questions-title" className="display-2">
                Scope, stated.
              </h2>
            </div>
            <p className="max-w-[44ch] text-sm leading-[1.65] text-body">
              Every claim on this page is scoped. Nothing here is a blanket statement about what the application can
              do.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-x-16 lg:grid-cols-2">
            <details className="faq-item" open>
              <summary>Is there a light theme?</summary>
              <p>
                No. The system is a warm dark canvas, deliberately. A light theme would need its own token set; if the
                application truly needs one, build it beside the dark tokens, not instead of them.
              </p>
            </details>
            <details className="faq-item">
              <summary>Where do the colours live?</summary>
              <p>
                In <code className="font-mono text-body-strong">tailwind.config.js</code> as token classes and in{' '}
                <code className="font-mono text-body-strong">index.css</code> as the ShadCN variables. No component
                carries a hex code.
              </p>
            </details>
            <details className="faq-item">
              <summary>Where can the terracotta appear?</summary>
              <p>
                The mark, the wordmark dot, eyebrow status dots, and states that need attention. Nothing else — never
                a button, a link, or a background.
              </p>
            </details>
            <details className="faq-item">
              <summary>What does the worker answer today?</summary>
              <p>
                <code className="font-mono text-body-strong">/api/test</code> returns a success envelope. Add routes
                in <code className="font-mono text-body-strong">worker/userRoutes.ts</code>; the file tree above
                switches on state, the same way a real one would.
              </p>
            </details>
          </div>
        </section>

        {/* ---------- Closing ---------- */}
        <section aria-labelledby="closing-title" className="mx-auto max-w-[1200px] border-t border-hairline px-6 py-24 text-center">
          <p className="eyebrow justify-center">build what comes next</p>
          <h2 id="closing-title" className="display-1 mb-[30px]" style={{ fontSize: 'clamp(34px, 4.6vw, 56px)' }}>
            Your next application.
            <br />
            Your style, handled.
          </h2>
          <Button asChild className="rounded-[3px] px-[18px] py-2.5 text-sm font-medium">
            <Link to="/console">
              Open console <span aria-hidden="true">&nbsp;↗</span>
            </Link>
          </Button>
        </section>
      </main>

      {/* ---------- Footer ---------- */}
      <footer className="border-t border-hairline">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center gap-6 px-6 py-10">
          <a href="#" aria-label={`${APP_NAME} home`} className="inline-flex items-center gap-[9px]">
            <PrysmMark className="h-[19px] w-[19px] text-mark" />
            <PrysmWordmark name={APP_NAME} />
          </a>
          <p className="m-0 text-[13px] text-mute">Built in the Prysm design system.</p>
          <nav aria-label="Footer navigation" className="ml-auto flex gap-6 text-[13px] text-body">
            <a href="#config" className="transition-colors hover:text-ink">
              Design notes
            </a>
            <a href="#questions" className="transition-colors hover:text-ink">
              Questions
            </a>
            <Link to="/console" className="transition-colors hover:text-ink">
              Console
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}
