# Template Selection

A Vite/React starter styled with the **Prysm design system**: a warm dark
canvas, one off-white ink, hairline borders, self-hosted Inter + DM Mono,
and a single terracotta accent carried by the brand mark. The home page is
a landing page and a console at once — hero, foundations strip and numbered
sections beside a panel with a mono service table.

Use when:
- The app belongs to the prysm.sh family — consoles, dashboards, admin
  panels, developer tools
- Landing pages or product pages for Prysm platform properties
- The user asks for the "Prysm look", the "prysm.sh style", or a
  dark, precise, typographic aesthetic

Avoid when:
- The app must be light-themed or match a different brand — the system is
  dark only
- Playful, colorful, gradient-heavy consumer apps — this system is
  deliberately restrained

Built with:
- React Router 6, ShadCN UI, Tailwind, lucide-react, Vite
- Cloudflare Workers + Hono for the API
- No extra dependencies beyond the base reference: the fonts are local
  files and the chrome is three small components
