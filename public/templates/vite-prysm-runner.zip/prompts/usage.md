# Usage

## Overview
Cloudflare Workers + React in the Prysm design system. The home page is a
landing page and a console at once.
- Frontend: React Router 6 + TypeScript + ShadCN UI, Prysm tokens
- Backend: Hono Worker (`worker/userRoutes.ts`)
- Design system: tokens in `src/index.css`, palette in `tailwind.config.js`,
  chrome in `src/components/prysm/`

## ⚠️ IMPORTANT: Mock Content
**The home page copy, the wordmark, the service table and every number on it
are MOCK CONTENT, shown to demonstrate the design system.**
- Replace the wordmark text (`APP_NAME` in `src/pages/HomePage.tsx`) with the
  application's name — lowercase, terracotta dot after it
- Replace the hero copy, section copy and footer copy with the application's
  own voice: short declarative sentences, no exclamation marks
- Replace the illustrative service table with real data from the worker
- Set a real `<title>` and meta description in `index.html`

## The design rules (do not break these)
1. **One rule above all:** the page is a warm dark canvas, one off-white,
   hairline borders. There is no chromatic accent in the interface — the
   brand mark carries the colour, not the UI.
2. **Tokens, not hex codes.** Use the palette classes: `bg-canvas`,
   `bg-canvas-soft`, `bg-canvas-raised`, `border-hairline`,
   `border-hairline-strong`, `text-ink`, `text-body`, `text-body-strong`,
   `text-mute`, `text-mark` / `bg-mark`. The shadcn semantic tokens
   (`bg-background`, `text-foreground`, `border`, …) already map onto this
   palette and keep every ShadCN component on-system automatically.
3. **Terracotta (`mark` #e0705a) appears only in:** the mark, the wordmark
   dot, eyebrow status dots, and states that need attention (e.g. a
   `degraded` service). Nothing else. Never as a button, link or background.
4. **Type.** Inter for narrative, DM Mono for anything a machine would read:
   labels, table cells, code, eyebrows, footers' footnotes. Narrative
   headings are `font-normal` (weight 400) with tight tracking
   (`-1.2px` / `-1.6px`) — plain declarations, not shouts. Body narrative
   uses `text-body`, emphasised text `text-body-strong`.
5. **Eyebrows.** A mono uppercase label (`eyebrow` class, 11px, 0.14em
   tracking, mute) above every section, optionally with a `status-dot`.
6. **Numbers count things.** Feature lists use mono indices `01 02 03` above
   a hairline top border (see `NumberedItem`), never bullets or cards with
   drop shadows.
7. **Radius is crisp.** 4px surfaces, 3px controls (`rounded` / `rounded-sm`
   are already mapped). Do not use `rounded-xl` or larger.
8. **No gradients, no glows, no glass.** Depth is a hairline border and at
   most one surface step (`canvas` → `canvas-soft` → `canvas-raised`).
9. **Buttons are inverted ink:** off-white face, canvas text — the shadcn
   default `Button` already does this. Do not colour buttons.
10. **Dark only.** There is no light theme; do not add one, and do not use
    `dark:` variants — the root is already dark.
11. **Icons** come from `lucide-react` and are small and monochrome. Arrows
    in links are characters (→ ↗), not icons — this is deliberate.

## Console chrome
- `Panel` (`src/components/prysm/panel.tsx`): the bordered surface with a
  bar of three dots, a mono uppercase title, an optional flag, and an
  optional foot (`{ label, code }`). Put real artifacts inside — tables,
  logs, code — never decorative screenshots.
- `console-table` (CSS class): mono table, hairline rows, uppercase mono
  header, tabular numbers for quantities.
- `StatusCell` (`src/components/prysm/status.tsx`): dot + word. Terracotta
  only for `degraded`; healthy stays neutral.
- `CodeBlock` (`src/components/prysm/code.tsx`): mono code on the raised
  panel. Mark tokens with spans: `tok-key` (lifted terracotta), `tok-str`
  (ink), `tok-num` (sand), `tok-c` (italic comment).
- `Explorer` (`src/components/prysm/explorer.tsx`): the file tree beside
  the file it selects — the one place an app shows the artifact a
  developer writes, not a picture of one. Takes flat `entries` (kind
  dir/file, depth), `active`, optional `onSelect`, optional `foot`.
- `SuiteList` (`src/components/prysm/suite.tsx`): mono tag + name + meta
  rows. At most one `primary` (inverted-ink tag) per list.
- `StatRow` / `LogLine` (`src/components/prysm/stat.tsx`): console stat
  blocks (label / tabular number / note) and log lines (quiet timestamp,
  machine message).
- `SiteNav` (`src/components/prysm/site-nav.tsx`): the shared nav. Hrefs
  starting with "/" render router links; anything else renders an anchor.
- `PrysmMark` / `PrysmWordmark` (`src/components/prysm/mark.tsx`): the brand
  mark path and the lowercase-name-plus-dot wordmark. Do not redraw the
  path.

## Pages
- `/` (`src/pages/HomePage.tsx`) — the landing: hero with the inspector
  panel, foundations strip, numbered features, config explorer, suite
  grid, questions (details/summary with the mono +/− marker), closing,
  footer. Replace the copy; keep the section shapes.
- `/console` (`src/pages/ConsolePage.tsx`) — the console: page head with
  an eyebrow, stat row, hairline metrics table, event log panel, config
  explorer. The shape every console page takes; add pages beside it and
  keep the shape.

## Tech
- React Router 6, ShadCN UI, Tailwind, Lucide, Hono, TypeScript

## Development Restrictions
- **Tailwind Colors**: Use the Prysm token classes; new colors go in
  `tailwind.config.js`, NOT in `index.css`
- **Fonts**: Inter and DM Mono are self-hosted in `public/fonts` — do not add
  a font CDN link
- **Components**: Use existing ShadCN components instead of writing custom
  ones; restyle via tokens, not component rewrites
- **Error Handling**: `ErrorBoundary`/`RouteErrorBoundary` are
  pre-implemented and already on-system
- **Worker Patterns**: Follow exact patterns in `worker/index.ts`;
  `worker/index.ts` and `worker/core-utils.ts` must not be modified

## Code Organization

### Frontend Structure
- `src/pages/HomePage.tsx` - Prysm landing + console mock (replace the copy,
  keep the system)
- `src/components/prysm/mark.tsx` - the brand mark and wordmark
- `src/components/prysm/panel.tsx` - `Panel` and `NumberedItem` console chrome
- `src/components/ThemeToggle.tsx` - theme switching (the system is dark
  only; if you keep it, it toggles the ShadCN class only — do not add a
  light palette)

### Backend Structure
- `worker/index.ts` - Worker entrypoint (registers routes; do not change
  patterns)
- `worker/userRoutes.ts` - Add routes here; `/api/test` answers today

### Shared
- Types for API responses go in a `shared/` folder you create, typed once,
  imported by both sides

## API Patterns

### Adding Endpoints
Follow the pattern in `worker/userRoutes.ts`:
```typescript
app.get('/api/metrics', (c) => c.json({
    success: true,
    data: { services: [/* ... */] },
}));
```

## Routing (CRITICAL)
Uses `createBrowserRouter` - do NOT switch to `BrowserRouter`/`HashRouter`.
If you switch routers, `RouteErrorBoundary`/`useRouteError()` will not work.

**Add routes in `src/main.tsx`** (the template ships `/` and `/console`):
```tsx
const router = createBrowserRouter([
  { path: "/", element: <HomePage />, errorElement: <RouteErrorBoundary /> },
  { path: "/console", element: <ConsolePage />, errorElement: <RouteErrorBoundary /> },
  { path: "/new", element: <NewPage />, errorElement: <RouteErrorBoundary /> },
]);
```

**Navigation:** `import { Link } from 'react-router-dom'` then `<Link to="/new">New</Link>`

**Don't:**
- Use `BrowserRouter`, `HashRouter`, `MemoryRouter`
- Remove `errorElement` from routes
- Use `useRouteError()` in your components

## UI Components
All ShadCN components are in `./src/components/ui/*`. Import and use them
directly:
```tsx
import { Button } from "@/components/ui/button";
```
**Do not rewrite these components** — the semantic tokens already put them
on the Prysm palette.
